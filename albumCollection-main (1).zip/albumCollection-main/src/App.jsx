import AlbumCollection from "./components/AlbumCollection";

export default function App() {
  return (
    <>
      <AlbumCollection />
    </>
  );
}
